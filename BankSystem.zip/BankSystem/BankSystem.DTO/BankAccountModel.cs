﻿namespace BankSystem.DTO
{

    //No mapping !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!11


    public class BankAccountModel
    {
        public int Id { get; set; }
    }
}
