﻿namespace BankSystem.Models.Enums
{
    public enum BankAccountType
    {
        Checking = 1,
        Savings = 2,
        Retirement = 3,
        Credit = 4
    }
}
