﻿namespace BankSystem.Services.Contracts
{
    public interface ICardService
    {
        //void AddCard(CardModel card);

        //void DeleteCard(CardModel card);

        //void DeleteCard(int id);

        //void UpdateCardInfo(int cardId, string pin, DateTime expirationTime);

        //ClientModel Owner(CardModel card);

        ////get bankAcount

        //CardModel GetCardById(int id);
    }
}
